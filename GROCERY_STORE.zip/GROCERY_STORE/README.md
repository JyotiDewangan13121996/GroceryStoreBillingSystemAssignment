======= BILLING DESK FOR GROCERY STORE=====

- Product Examples ::

Id |  BarCode |  Description | Price

1  |   01001  |  Banana      | 0.99

2  |   01002  |  Apple       | 1.30

3  |   01003  |  Carrot      | 1.66

4  |   01004  |  Cucumber    | 1.25

5  |   01005  |  Mushroom    | 5.50

6  |   01006  |  Beetroot    | 1.20

7  |   01007  |  Tomato      | 2


---------------------------------
Added productId in the Product class to use it as unique identifier.

==================================

INSTRUCTIONS TO RUN PROJECT:


- Build maven project and install all the dependencies .
- Run the project.

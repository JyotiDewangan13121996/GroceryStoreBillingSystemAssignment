package com.app.utility;

import com.app.dao.OrderForBilling;
import com.app.dao.Product;
import com.app.service.OrderBillingServiceImplementation;
import com.app.service.ProductServiceImplementation;

import java.math.BigInteger;
import java.util.Scanner;

public class Menu {

    private Scanner input = new Scanner(System.in);

    private OrderBillingServiceImplementation orderBillingServiceImplementation = new OrderBillingServiceImplementation();

    private ProductServiceImplementation productServiceImplementation = new ProductServiceImplementation();

    //Main menu for Billing System
    public void mainMenu(){

        int choice=0;
        while(choice!=4) {
            System.out.println();
            System.out.println("=============================GROCERY STORE ==========================");
            System.out.println();
            System.out.println("*******************************MAIN MENU***************************");
            System.out.println("1. Add Item To Basket For Billing");
            System.out.println("2. Remove Item From Basket For Billing");
            System.out.println("3. Print Order Summary");
            System.out.println("4.Exit");
            System.out.println();
            System.out.println("Enter Your Choice : ");
            choice = input.nextInt();
            operationsOnMainMenuCorrespondingToChoice(choice);
        }

    }

    private void operationsOnMainMenuCorrespondingToChoice(Integer choice){
        switch (choice){
            case 1 : subMenuForAddingProductToBasketForBilling();
                     break;
            case 2 : subMenuForRemovingProductFromBasketForBilling();
                     break;
            case 3 : printOrderSummary();
                     break;
            case 4 : System.exit(0);
            default :
                    System.out.println("Invalid Choice ! Re-enter your choice !");
        }
    }

    // Prints Summary Of The Order
    private void printOrderSummary() {
       orderBillingServiceImplementation.printOrderSummary();
    }

    //Sub-Menu For Removing Product From Basket for Billing
    private void subMenuForRemovingProductFromBasketForBilling() {
        System.out.println();
        System.out.println("================Remove Product From Bakset ===============");
        Product productToBeRemoved = getProductByScanningBarCode();
        orderBillingServiceImplementation.removeProductFromBasketForBilling(productToBeRemoved);
    }

    //Sub-Menu For Adding Product To Basket for Billing
    private void subMenuForAddingProductToBasketForBilling(){
        System.out.println();
        System.out.println("================Add Product To Bakset ===============");
        OrderForBilling orderForBillingToBeAdded = getOrderForBilling();
        orderBillingServiceImplementation.addProductToBasketForBilling(orderForBillingToBeAdded);
    }

    private OrderForBilling getOrderForBilling() {

        Product product = getProductByScanningBarCode();
        int qauntity = getQauntityOfProduct(product);
        double subTotal = qauntity * product.getPrice();
        OrderForBilling orderForBilling = new OrderForBilling(product, qauntity , subTotal);
        return orderForBilling;
    }

    private int getQauntityOfProduct(Product product) {
        System.out.println();
        System.out.println("Enter the Qauntity for " + product.getDescription() + " : ");
        int qauntity = input.nextInt();
        return qauntity;
    }

    private Product getProductByScanningBarCode() {
        System.out.println("");
        System.out.println("Enter the Bar Code of Product : ");
        String barCode = input.next();
        Product product = productServiceImplementation.getProductByBarCode(barCode);
        verifyInvalidProductBarCode(product);
        System.out.println();
        System.out.println("Product Details :: " + product);
        return product;
    }

    private void verifyInvalidProductBarCode(Product product) {
        if(product ==null){
            System.out.println("Invalid BarCode For Product ");
            mainMenu();
        }
    }
}

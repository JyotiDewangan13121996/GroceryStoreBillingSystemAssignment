package com.app.dao;

public class OrderForBilling {

    private Product product;
    private Integer quantity;
    private double subTotal;

    public OrderForBilling( Product product, Integer quantity, double subTotal) {
        this.product = product;
        this.quantity = quantity;
        this.subTotal = subTotal;
    }

    public Product getProduct() {
        return product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public double getSubTotal() {
        return subTotal;
    }

}

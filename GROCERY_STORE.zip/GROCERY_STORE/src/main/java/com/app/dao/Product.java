package com.app.dao;

import java.util.Objects;

public class Product {

    private Integer productID;
    private String barCode;
    private String description;
    private double price ;

    public Product(Integer productID, String barCode, String description, double price) {
        this.productID = productID;
        this.barCode = barCode;
        this.description = description;
        this.price = price;
    }

    public Integer getProductID() {
        return productID;
    }

    public String getBarCode() {
        return barCode;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }


    @Override
    public String toString() {
        return "Product{" +
                "productID=" + productID +
                ", barCode='" + barCode + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                '}';
    }
}

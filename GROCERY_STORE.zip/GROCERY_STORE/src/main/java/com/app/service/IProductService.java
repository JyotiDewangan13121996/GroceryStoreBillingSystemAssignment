package com.app.service;

import com.app.dao.Product;

import java.util.List;

public interface IProductService {

    //To display list of all the Products
    List<Product> getListOfProducts();

    // Find a product by its barcode
    Product getProductByBarCode(String barCode);


}

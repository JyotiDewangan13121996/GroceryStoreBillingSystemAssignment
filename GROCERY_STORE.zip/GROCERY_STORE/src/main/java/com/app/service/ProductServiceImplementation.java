package com.app.service;

import com.app.dao.Product;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProductServiceImplementation implements IProductService {

    private List<Product> productList = new ArrayList<Product>(
            Arrays.asList(
                    new Product(1,"01001" , "Banana" , 0.99),
                    new Product(2,"01002" , "Apple" , 1.30),
                    new Product(3,"01003" , "Carrot" , 1.66),
                    new Product(4,"01004" , "Cucumber", 1.25 ),
                    new Product(5,"01005","Mushroom", 5.50) ,
                    new Product(6,"01006", "Beetroot", 1.20),
                    new Product(7,"01007", "Tomato",2)
            )
    );

    @Override
    public List<Product> getListOfProducts() {
        return productList;
    }

    @Override
    public Product getProductByBarCode(String barCode) {
        Product product = null;
        int productId = Integer.parseInt(barCode.substring(3));
        for (Product productInList: productList) {
            if(productInList.getProductID().equals(productId))
                product = productInList;
        }
        return product;
    }
}

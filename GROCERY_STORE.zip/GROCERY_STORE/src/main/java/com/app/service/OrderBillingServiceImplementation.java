package com.app.service;

import com.app.dao.OrderForBilling;
import com.app.dao.Product;

import java.util.ArrayList;
import java.util.List;

public class OrderBillingServiceImplementation implements IOrderBillingService{

    private List<OrderForBilling> orderForBillingList = new ArrayList<OrderForBilling>();

    @Override
    public void addProductToBasketForBilling(OrderForBilling orderForBillingToBeAdded) {
        orderForBillingList.add(orderForBillingToBeAdded);
        System.out.println("Product - "+ orderForBillingToBeAdded.getProduct().getDescription()  + " added to Basket Succesfully !!!");
    }

    @Override
    public void removeProductFromBasketForBilling(Product productToBeRemoved) {

        OrderForBilling orderForBillingToBeRemovedFromBasket = null;
        for (OrderForBilling orderForBilling:orderForBillingList) {
          if(orderForBilling.getProduct().getProductID().equals(productToBeRemoved.getProductID())) {
              orderForBillingToBeRemovedFromBasket=orderForBilling;
              break;
          }
        }
        orderForBillingList.remove(orderForBillingToBeRemovedFromBasket);
        System.out.println("Product - "+ productToBeRemoved.getDescription()  + " removed from Basket Succesfully !!!");
    }

    @Override
    public void printOrderSummary() {
            double total = 0;
            System.out.println("============ ORDER SUMMARY =================");

            if(isBasketEmptyForBilling())
                System.out.println("Bakset is Empty for Billing !!!");
            else
            {
                for ( OrderForBilling orderForBilling: orderForBillingList) {
                    System.out.println( orderForBilling.getQuantity()  + " x " + orderForBilling.getProduct().getDescription() +
                            " @ " + orderForBilling.getProduct().getPrice() + " = " + orderForBilling.getSubTotal());
                    total+=orderForBilling.getSubTotal();
                }
                System.out.println("-------------------------------------------------------------------");
                System.out.println("Total = " + total);
            }
    }

    @Override
    public boolean isBasketEmptyForBilling() {
        return orderForBillingList.isEmpty();
    }

}

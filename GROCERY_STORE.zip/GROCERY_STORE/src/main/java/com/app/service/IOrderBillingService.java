package com.app.service;

import com.app.dao.OrderForBilling;
import com.app.dao.Product;

public interface IOrderBillingService {

    // Add product to Basket for Billing
    void addProductToBasketForBilling(OrderForBilling orderForBilling);

    //Remove product from the Basket For Billing
    void removeProductFromBasketForBilling(Product product);

    // Print Order Summary
    void printOrderSummary();

    //Check Is Basket Empty Or Not
    boolean isBasketEmptyForBilling();

}

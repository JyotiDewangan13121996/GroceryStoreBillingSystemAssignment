package com.app;

import com.app.utility.Menu;

public class BillingSystemForGroceryStore {

    public  static void  main(String[] args){

        Menu menu = new Menu();
        menu.mainMenu();
    }
}
